import io, sys
import time
import ayane.Ayane as ayane
import shogi as sg

# エンジンクラス
class Engine:
    def __init__(self):
        # メンバ
        self.Eng = ayane.UsiEngine()    # UsiEngineオブジェクト
        self.Id  = None                 # 0,1の2つ
        self.Exe = False                # 実行中フラグ
        self.Pos = ""                   # 指し手
        self.Res = ""                   # Cmdに対するResult
        self.BM  = ""                   # Cmdに対するbestmove
        self.PD  = ""                   # Cmdに対するponder
        self.Dp  = 0                    # 最終的な読み深さ
        self.CP  = 0                    # bestmoveの評価値
        self.Tm  = 0                    # goからの経過時間（ms）

    def clear(self):
        # Idはクリアしちゃダメよ！
        self.Exe = False                # 実行中フラグ
        self.Pos = ""                   # 指し手
        self.Res = ""                   # Cmdに対するResult
        self.BM  = ""                   # Cmdに対するbestmove
        self.PD  = ""                   # Cmdに対するponder
        self.Dp  = 0                    # 最終的な読み深さ
        self.CP  = 0                    # bestmoveの評価値
        self.Tm  = 0                    # goからの経過時間（ms）

    def think(self, pos):
        self.Eng.usi_position(self.Pos)
        self.Exe = True
        self.Eng.usi_go_and_wait_bestmove(pos)
        self.Exe = False
        self.Res = self.Eng.think_result.to_string()
        self.BM  = self.Eng.think_result.bestmove
        self.PD  = self.Eng.think_result.ponder
        self.Dp  = self.Eng.think_result.pvs[0].depth
        self.CP  = self.Eng.think_result.pvs[0].eval
        self.Tm  = self.Eng.think_result.pvs[0].time

# 初期化
def Init():
    global pd, cpos, ef
    cpos = ""
    pd = Engine()
    pd.Id = 0
    pd.Eng.set_engine_options({"Hash":"128", "Threads":"1", "MultiPV":"1", "BookFile":"no_book"})
    pd.Eng.connect(ef[0])
 
# クリア処理（エンジンを止めて変数クリアしてreadyok状態にする）
def AllClear():
    global pd
    if pd.Exe:
        pd.Eng.usi_stop()
        pd.Eng.wait_bestmove()
    pd.Eng.send_command("usinewgame")
    pd.Eng.send_command("isready")
    pd.clear()

# 終了処理
def Close():
    global pd
    pd.Eng.disconnect()

# メイン処理
lc   = 100
byo  = "30000"
ef   = [ "exe1/Kristallweizen-t" ]
tu   = [ 0, 1 ]
go   = "byoyomi " + byo
pd   = None   # エンジン用オブジェクト

# エンジン初期化
Init()

# 指定回数、対局を行わせる
for c in range(lc):
    print("{0:5d}局目".format(c + 1))
    AllClear()
    teban  = 0
    tesu   = 1
    sfen   = ""
    cPos   = "startpos moves"
    cMoves = ""
    bMoves = ""
    isDraw = False
    brd    = sg.Board()
    print("SFEN,BestMove,eval,Depth,Time")
    while True:
        if cMoves != "":
            cPos += " " + cMoves
        sfen = brd.sfen()
        pd.Pos = cPos
        pd.think(go)
        print("{0},{1},{2},{3},{4}".format(sfen, pd.BM, pd.CP, pd.Dp, pd.Tm))
        wkCp = pd.CP
        if wkCp is None:
            wkCp = 0
        if "mate" in pd.Res:
            gomi, wkStrA = pd.Res.split(" mate ")
            wkStrB = wkStrA.split(" ")
            wkCp = -10001 if int(wkStrB[0]) < 0 else 10001
        if teban == 1:
            wkCp *= -1
        if wkCp > 10000:
            wkCp = 10000    # 10000でカンスト
            break
        elif wkCp < -10000:
            wkCp = -10000   # -10000でカンスト
            break
        bMoves = cMoves
        cMoves = pd.BM
        if teban == 0:
            teban = 1
        else:
            teban = 0
        brd.push_usi(cMoves)
        tesu += 1
        if tesu > 320:      # 手数が320を越えたら
            isDraw = True   # 引き分けとみなす
            break

    if isDraw:
        print("引き分け")
    elif teban == 0:
        print("先手勝ち")
    else:
        print("後手勝ち")

    tu[0], tu[1] = tu[1], tu[0]

Close()
